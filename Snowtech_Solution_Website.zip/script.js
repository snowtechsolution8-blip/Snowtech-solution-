const menu=document.querySelector(".menu"), nav=document.querySelector("#navlinks");
menu.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll("#navlinks a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
document.querySelector("#contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  const f=new FormData(e.target);
  const subject=encodeURIComponent("New inquiry for Snowtech Solution");
  const body=encodeURIComponent(`Name: ${f.get("name")}\nEmail: ${f.get("email")}\n\nMessage:\n${f.get("message")}`);
  // Replace the email address below with your business email before publishing.
  window.location.href=`mailto:YOUR_EMAIL@example.com?subject=${subject}&body=${body}`;
});
